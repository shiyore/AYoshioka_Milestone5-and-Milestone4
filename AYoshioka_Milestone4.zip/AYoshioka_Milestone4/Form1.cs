﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace AYoshioka_Milestone3
{
    public partial class Form1 : Form
    {
        //All my new forms
        private ItemSheet f;
        private ListInv listInv;
        private RemoveItem remItem;
        private Restock restock;
        private Search search;

        // my variables
        public static InventoryManager inventory;
        public static ArrayList invList;
        public Form1()
        {
            inventory = new InventoryManager();
            invList = inventory.getAllInv();
            InitializeComponent();
        }

        private void b_add_Click(object sender, EventArgs e)
        {
            f = new ItemSheet();
            Hide();
            f.ShowDialog();
            Show();
            Int32 aisle = 0; 
            Int32.TryParse(((ItemSheet)f).tb_aisle.Text, out aisle);
            long ID = 0;
            long.TryParse(((ItemSheet)f).tb_ID.Text, out ID);
            double price = 0;
            Double.TryParse(((ItemSheet)f).tb_price.Text, out price);
            Int32 count = 0;
            Int32.TryParse(((ItemSheet)f).tb_count.Text, out count);
            string name = ((ItemSheet)f).tb_name.Text;
            inventory.addInv(new InventoryItem(count, price, aisle, ID, name));
        }

        private void b_remove_Click(object sender, EventArgs e)
        {
            remItem = new RemoveItem();
            Hide();
            remItem.ShowDialog();
            Show();

        }

        private void b_view_Click(object sender, EventArgs e)
        {
            listInv = new ListInv();
            Hide();
            listInv.ShowDialog();
            String invString = "";
            ArrayList inv = inventory.getAllInv();
            foreach(InventoryItem n in inv)
            {
                invString += n.getItemName() + ": " + n.getItemID() + "\n";
            }
            Show();
            ((ListInv)listInv).tb_inventory.Text = invString;
            ((ListInv)listInv).lb_title.Text = "Nothing here";
        }

        private void b_restock_Click(object sender, EventArgs e)
        {
            restock = new Restock();
            Hide();
            restock.ShowDialog();
            Show();
        }

        private void b_search_Click(object sender, EventArgs e)
        {
            search = new Search();
            Hide();
            search.ShowDialog();
            Show();
        }
    }
}
