﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AYoshioka_Milestone3
{
    public partial class ItemSheet : Form
    {
        public ItemSheet()
        {
            InitializeComponent();
        }

        private void btn_submit_Click(object sender, EventArgs e)
        {
            if(tb_aisle.Text != "" && tb_count.Text != "" && tb_price.Text != "" && tb_ID.Text != "" && tb_name.Text != "")
            {
                Hide();
            }
            else
            {
                lb_name.Text = "Not all fields have been filled out yet";
            }
        }
    }
}
