﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace AYoshioka_Milestone3
{
    public class InventoryManager
    {
        private ArrayList inventory;

        public InventoryManager()
        {
            inventory = new ArrayList();
        }

        public void addInv(InventoryItem item)
        {
            inventory.Add(item);
        }
        public void removeInv(int ID)
        {
            foreach(InventoryItem n in inventory)
            {
                if(n.getItemID() == ID)
                {
                    inventory.Remove(n);
                    break;
                }
            }
        }
        public InventoryItem getInv(int ID)
        {
            InventoryItem temp = null;
            foreach (InventoryItem n in inventory)
            {
                if (n.getItemID() == ID)
                {
                    temp = n;
                    break;
                }
            }
            return temp;
        }
        public void restockInv(int ID , int amount)
        {
            InventoryItem temp = null;
            foreach (InventoryItem n in inventory)
            {
                if (n.getItemID() == ID)
                {
                    temp = n;
                    break;
                }
            }
            temp.setItemCount(amount);
        }
        public ArrayList searchByPrice(double price)
        {
            ArrayList temp = new ArrayList();
            foreach (InventoryItem n in inventory)
            {
                if (n.getPrice() == price)
                {
                    temp.Add(n);
                }
            }
            return temp;
        }
        public ArrayList searchByAisle(Int32 aisle)
        {
            ArrayList temp = new ArrayList();
            foreach (InventoryItem n in inventory)
            {
                if (n.getAisleNumber() == aisle)
                {
                    temp.Add(n);
                }
            }
            return temp;
        }
        public ArrayList searchByID(Int32 ID)
        {
            ArrayList temp = new ArrayList();
            foreach (InventoryItem n in inventory)
            {
                if (n.getItemID() == ID)
                {
                    temp.Add(n);
                }
            }
            return temp;
        }
        public ArrayList getAllInv()
        {
            return inventory;
        }
    }
}
