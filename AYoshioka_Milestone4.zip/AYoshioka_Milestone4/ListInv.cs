﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AYoshioka_Milestone3
{
    public partial class ListInv : Form
    {
        public ListInv()
        {
            
            InitializeComponent();
        }
        private void ListInv_Load(object sender , EventArgs e)
        {
            String invString = "Name: ID\n-------------------------------\n";
            if (Form1.invList.Count > 0)
            {
                foreach (InventoryItem n in Form1.invList)
                {
                    invString += n.getItemName() + ": " + n.getItemID() + "\n";
                }
            }
            else
            {
                invString = "Nothing in here yet";
            }
            tb_inventory.Text = "Item";
        }
        private void btn_back_Click(object sender, EventArgs e)
        {
            Hide();
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void ListInv_Load_1(object sender, EventArgs e)
        {
            String invString = "Name: ID : Price : Amount : Aisle\n-------------------------------\n";
            if (Form1.invList.Count > 0)
            {
                foreach (InventoryItem n in Form1.invList)
                {
                    invString += n.getItemName() + " : " + n.getItemID() + " : $" + n.getPrice() + " : " + n.getItemCount() + " : " + n.getAisleNumber() +"\n";
                }
            }
            else
            {
                invString = "Nothing in here yet";
            }
            tb_inventory.Text = invString;
        }
    }
}
