﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace AYoshioka_Milestone3
{
    public partial class RemoveItem : Form
    {
        public RemoveItem()
        {
            InitializeComponent();
        }

        private void btn_remove_Click(object sender, EventArgs e)
        {
            int ID = 0;
            Int32.TryParse(tb_ID.Text, out ID);
            ArrayList temp = Form1.inventory.searchByID(ID);
            if(temp.Count > 0)
            {
                lb_status.Text = "Item has been deleted from the inventory";
                Form1.inventory.removeInv(ID);
            }
            else
            {
                lb_status.Text = "No items found with this ID";
            }
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            Hide();
        }
    }
}
