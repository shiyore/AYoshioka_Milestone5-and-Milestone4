﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;


//This is my code to handle whether an item can be restocked or not given an ID
namespace AYoshioka_Milestone3
{
    public partial class Restock : Form
    {
        public Restock()
        {
            InitializeComponent();
        }

        private void btn_restock_Click(object sender, EventArgs e)
        {
            int ID = 0;
            int amount = 0;
            Int32.TryParse(tb_ID.Text, out ID);
            ArrayList temp = Form1.inventory.searchByID(ID);

            //Determines whether a valid ID and amount has been given before restocking
            if (temp.Count > 0)
            {
                if (tb_amount.Text != "" && Int32.TryParse(tb_amount.Text, out amount))
                {
                    lb_status.Text = "Item has been restocked";
                    Form1.inventory.getInv(ID).setItemCount(amount);
                }
                else
                {
                    lb_status.Text = "No amount has been entered";
                }
            }
            else
            {
                lb_status.Text = "No items found with this ID";
            }
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            Hide();
        }
    }
}
