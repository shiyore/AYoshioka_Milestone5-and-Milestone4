﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace AYoshioka_Milestone3
{
    public partial class Search : Form
    {
        private static String searchString = "Name: ID\n-------------------------------\n";
        private ArrayList inv = new ArrayList();
        public Search()
        {
            InitializeComponent();
        }

        private void btn_searchAisle_Click(object sender, EventArgs e)
        {
            int aisle = 0;
            if(Int32.TryParse(tb_input.Text , out aisle))
            {
                inv = Form1.inventory.searchByAisle(aisle);
                foreach (InventoryItem n in inv)
                {
                    searchString += n.getItemName() + ": " + n.getItemID() + "\n";
                }
            }
            else
            {
                searchString = "ERROR: Invalid aisle input";
            }
            tb_inv.Text = searchString;
        }

        private void btn_searchPrice_Click(object sender, EventArgs e)
        {
            double price = 0;
            if (Double.TryParse(tb_input.Text, out price))
            {
                inv = Form1.inventory.searchByPrice(price);
                foreach (InventoryItem n in inv)
                {
                    searchString += n.getItemName() + ": " + n.getItemID() + "\n";
                }
            }
            else
            {
                searchString = "ERROR: Invalid price input";
            }
            tb_inv.Text = searchString;
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            Hide();
        }
    }
}
