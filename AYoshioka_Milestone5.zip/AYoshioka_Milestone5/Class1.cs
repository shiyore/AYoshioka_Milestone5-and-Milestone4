﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AYoshioka_Milestone3
{
    class Class1
    {
    }
}
