﻿namespace AYoshioka_Milestone3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.b_add = new System.Windows.Forms.Button();
            this.b_remove = new System.Windows.Forms.Button();
            this.b_view = new System.Windows.Forms.Button();
            this.b_restock = new System.Windows.Forms.Button();
            this.b_search = new System.Windows.Forms.Button();
            this.lb_add = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // b_add
            // 
            this.b_add.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b_add.Location = new System.Drawing.Point(45, 37);
            this.b_add.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.b_add.Name = "b_add";
            this.b_add.Size = new System.Drawing.Size(160, 45);
            this.b_add.TabIndex = 0;
            this.b_add.Text = "Add";
            this.b_add.UseVisualStyleBackColor = true;
            this.b_add.Click += new System.EventHandler(this.b_add_Click);
            // 
            // b_remove
            // 
            this.b_remove.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b_remove.Location = new System.Drawing.Point(45, 117);
            this.b_remove.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.b_remove.Name = "b_remove";
            this.b_remove.Size = new System.Drawing.Size(160, 45);
            this.b_remove.TabIndex = 1;
            this.b_remove.Text = "Remove";
            this.b_remove.UseVisualStyleBackColor = true;
            this.b_remove.Click += new System.EventHandler(this.b_remove_Click);
            // 
            // b_view
            // 
            this.b_view.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b_view.Location = new System.Drawing.Point(45, 194);
            this.b_view.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.b_view.Name = "b_view";
            this.b_view.Size = new System.Drawing.Size(160, 45);
            this.b_view.TabIndex = 2;
            this.b_view.Text = "View";
            this.b_view.UseVisualStyleBackColor = true;
            this.b_view.Click += new System.EventHandler(this.b_view_Click);
            // 
            // b_restock
            // 
            this.b_restock.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b_restock.Location = new System.Drawing.Point(45, 280);
            this.b_restock.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.b_restock.Name = "b_restock";
            this.b_restock.Size = new System.Drawing.Size(160, 45);
            this.b_restock.TabIndex = 3;
            this.b_restock.Text = "Restock";
            this.b_restock.UseVisualStyleBackColor = true;
            this.b_restock.Click += new System.EventHandler(this.b_restock_Click);
            // 
            // b_search
            // 
            this.b_search.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b_search.Location = new System.Drawing.Point(45, 362);
            this.b_search.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.b_search.Name = "b_search";
            this.b_search.Size = new System.Drawing.Size(160, 45);
            this.b_search.TabIndex = 4;
            this.b_search.Text = "Search";
            this.b_search.UseVisualStyleBackColor = true;
            this.b_search.Click += new System.EventHandler(this.b_search_Click);
            // 
            // lb_add
            // 
            this.lb_add.AutoSize = true;
            this.lb_add.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_add.Location = new System.Drawing.Point(259, 42);
            this.lb_add.Name = "lb_add";
            this.lb_add.Size = new System.Drawing.Size(521, 40);
            this.lb_add.TabIndex = 5;
            this.lb_add.Text = "Add a new item to the inventory";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(259, 122);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(577, 40);
            this.label2.TabIndex = 6;
            this.label2.Text = "Remove an item from the inventory";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(259, 199);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(311, 40);
            this.label3.TabIndex = 7;
            this.label3.Text = "View the inventory";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(259, 280);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(574, 40);
            this.label4.TabIndex = 8;
            this.label4.Text = "Restock an Item from the inventory";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(259, 367);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(533, 40);
            this.label5.TabIndex = 9;
            this.label5.Text = "Search for items in the inventory";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(835, 421);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lb_add);
            this.Controls.Add(this.b_search);
            this.Controls.Add(this.b_restock);
            this.Controls.Add(this.b_view);
            this.Controls.Add(this.b_remove);
            this.Controls.Add(this.b_add);
            this.Name = "Form1";
            this.Text = "AYoshioka Milestone 4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button b_add;
        private System.Windows.Forms.Button b_remove;
        private System.Windows.Forms.Button b_view;
        private System.Windows.Forms.Button b_restock;
        private System.Windows.Forms.Button b_search;
        private System.Windows.Forms.Label lb_add;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
    }
}

