﻿using System.Windows.Forms;

namespace AYoshioka_Milestone3
{
    partial class ItemSheet
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb_ID = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lb_price = new System.Windows.Forms.Label();
            this.tb_price = new System.Windows.Forms.TextBox();
            this.lb_count = new System.Windows.Forms.Label();
            this.tb_count = new System.Windows.Forms.TextBox();
            this.lb_aisle = new System.Windows.Forms.Label();
            this.tb_aisle = new System.Windows.Forms.TextBox();
            this.lb_name = new System.Windows.Forms.Label();
            this.tb_name = new System.Windows.Forms.TextBox();
            this.btn_submit = new System.Windows.Forms.Button();
            this.pb_itemImage = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pb_itemImage)).BeginInit();
            this.SuspendLayout();
            // 
            // tb_ID
            // 
            this.tb_ID.Location = new System.Drawing.Point(117, 149);
            this.tb_ID.Name = "tb_ID";
            this.tb_ID.Size = new System.Drawing.Size(207, 26);
            this.tb_ID.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 152);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "Item ID:";
            // 
            // lb_price
            // 
            this.lb_price.AutoSize = true;
            this.lb_price.Location = new System.Drawing.Point(12, 226);
            this.lb_price.Name = "lb_price";
            this.lb_price.Size = new System.Drawing.Size(84, 20);
            this.lb_price.TabIndex = 3;
            this.lb_price.Text = "Item Price:";
            // 
            // tb_price
            // 
            this.tb_price.Location = new System.Drawing.Point(117, 220);
            this.tb_price.Name = "tb_price";
            this.tb_price.Size = new System.Drawing.Size(207, 26);
            this.tb_price.TabIndex = 2;
            // 
            // lb_count
            // 
            this.lb_count.AutoSize = true;
            this.lb_count.Location = new System.Drawing.Point(11, 301);
            this.lb_count.Name = "lb_count";
            this.lb_count.Size = new System.Drawing.Size(92, 20);
            this.lb_count.TabIndex = 5;
            this.lb_count.Text = "Item Count:";
            // 
            // tb_count
            // 
            this.tb_count.Location = new System.Drawing.Point(117, 295);
            this.tb_count.Name = "tb_count";
            this.tb_count.Size = new System.Drawing.Size(207, 26);
            this.tb_count.TabIndex = 4;
            // 
            // lb_aisle
            // 
            this.lb_aisle.AutoSize = true;
            this.lb_aisle.Location = new System.Drawing.Point(11, 369);
            this.lb_aisle.Name = "lb_aisle";
            this.lb_aisle.Size = new System.Drawing.Size(83, 20);
            this.lb_aisle.TabIndex = 7;
            this.lb_aisle.Text = "Item Aisle:";
            // 
            // tb_aisle
            // 
            this.tb_aisle.Location = new System.Drawing.Point(117, 366);
            this.tb_aisle.Name = "tb_aisle";
            this.tb_aisle.Size = new System.Drawing.Size(207, 26);
            this.tb_aisle.TabIndex = 6;
            // 
            // lb_name
            // 
            this.lb_name.AutoSize = true;
            this.lb_name.Location = new System.Drawing.Point(347, 29);
            this.lb_name.Name = "lb_name";
            this.lb_name.Size = new System.Drawing.Size(91, 20);
            this.lb_name.TabIndex = 9;
            this.lb_name.Text = "Item Name:";
            // 
            // tb_name
            // 
            this.tb_name.Location = new System.Drawing.Point(293, 61);
            this.tb_name.Name = "tb_name";
            this.tb_name.Size = new System.Drawing.Size(207, 26);
            this.tb_name.TabIndex = 8;
            // 
            // btn_submit
            // 
            this.btn_submit.Location = new System.Drawing.Point(351, 451);
            this.btn_submit.Name = "btn_submit";
            this.btn_submit.Size = new System.Drawing.Size(75, 36);
            this.btn_submit.TabIndex = 10;
            this.btn_submit.Text = "Submit";
            this.btn_submit.UseVisualStyleBackColor = true;
            this.btn_submit.Click += new System.EventHandler(this.btn_submit_Click);
            // 
            // pb_itemImage
            // 
            this.pb_itemImage.BackgroundImage = global::AYoshioka_Milestone3.Properties.Resources.no_image_icon_11;
            this.pb_itemImage.InitialImage = global::AYoshioka_Milestone3.Properties.Resources.no_image_icon_11;
            this.pb_itemImage.Location = new System.Drawing.Point(473, 135);
            this.pb_itemImage.Name = "pb_itemImage";
            this.pb_itemImage.Size = new System.Drawing.Size(277, 257);
            this.pb_itemImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_itemImage.TabIndex = 11;
            this.pb_itemImage.TabStop = false;
            // 
            // ItemSheet
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(829, 499);
            this.Controls.Add(this.pb_itemImage);
            this.Controls.Add(this.btn_submit);
            this.Controls.Add(this.lb_name);
            this.Controls.Add(this.tb_name);
            this.Controls.Add(this.lb_aisle);
            this.Controls.Add(this.tb_aisle);
            this.Controls.Add(this.lb_count);
            this.Controls.Add(this.tb_count);
            this.Controls.Add(this.lb_price);
            this.Controls.Add(this.tb_price);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tb_ID);
            this.Name = "ItemSheet";
            this.Text = "Inventory Item";
            ((System.ComponentModel.ISupportInitialize)(this.pb_itemImage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lb_price;
        private System.Windows.Forms.Label lb_count;
        private System.Windows.Forms.Label lb_aisle;
        private System.Windows.Forms.Label lb_name;
        private System.Windows.Forms.Button btn_submit;
        public System.Windows.Forms.TextBox tb_ID;
        public System.Windows.Forms.TextBox tb_price;
        public System.Windows.Forms.TextBox tb_count;
        public System.Windows.Forms.TextBox tb_aisle;
        public System.Windows.Forms.TextBox tb_name;
        public System.Windows.Forms.PictureBox pb_itemImage;
    }
}