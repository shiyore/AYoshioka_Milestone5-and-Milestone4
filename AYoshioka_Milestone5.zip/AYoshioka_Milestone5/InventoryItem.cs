﻿using System;

public class InventoryItem
{
    private Int32 itemCount, aisleNumber;
    private double price;
    private long itemID;
    private String itemName;

    public InventoryItem()
    {
        this.itemName = "";
        this.price = 0;
        this.itemCount = 0;
        this.itemID = 000000;
        this.aisleNumber = -1;
    }
    public InventoryItem(Int32 itemCount, double price, Int32 aisleNumber, long itemID, String itemName)
    {
        this.itemName = itemName;
        this.price = price;
        this.itemCount = itemCount;
        this.itemID = itemID;
        this.aisleNumber = aisleNumber;
    }

    public void setItemName(String name)
    {
        this.itemName = name;
    }
    public String getItemName()
    {
        return itemName;
    }

    public void setPrice(double price)
    {
        this.price = price;
    }
    public double getPrice()
    {
        return price;
    }

    public void setItemID(Int32 ID)
    {
        this.itemID = ID;
    }
    public long getItemID()
    {
        return this.itemID;
    }

    public void setItemCount(Int32 count)
    {
        this.itemCount = count;
    }
    public Int32 getItemCount()
    {
        return itemCount;
    }

    public void setAisleNumber(Int32 aisleNumber)
    {
        this.aisleNumber = aisleNumber;
    }
    public Int32 getAisleNumber()
    {
        return aisleNumber;
    }
}
