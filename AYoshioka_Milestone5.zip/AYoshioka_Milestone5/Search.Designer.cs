﻿namespace AYoshioka_Milestone3
{
    partial class Search
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb_input = new System.Windows.Forms.TextBox();
            this.btn_searchAisle = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_searchPrice = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.tb_inv = new System.Windows.Forms.RichTextBox();
            this.btn_back = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // tb_input
            // 
            this.tb_input.Location = new System.Drawing.Point(140, 57);
            this.tb_input.Name = "tb_input";
            this.tb_input.Size = new System.Drawing.Size(239, 26);
            this.tb_input.TabIndex = 0;
            // 
            // btn_searchAisle
            // 
            this.btn_searchAisle.Location = new System.Drawing.Point(537, 55);
            this.btn_searchAisle.Name = "btn_searchAisle";
            this.btn_searchAisle.Size = new System.Drawing.Size(75, 31);
            this.btn_searchAisle.TabIndex = 1;
            this.btn_searchAisle.Text = "Aisle";
            this.btn_searchAisle.UseVisualStyleBackColor = true;
            this.btn_searchAisle.Click += new System.EventHandler(this.btn_searchAisle_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(396, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(135, 30);
            this.label1.TabIndex = 2;
            this.label1.Text = "Search by:";
            // 
            // btn_searchPrice
            // 
            this.btn_searchPrice.Location = new System.Drawing.Point(633, 55);
            this.btn_searchPrice.Name = "btn_searchPrice";
            this.btn_searchPrice.Size = new System.Drawing.Size(75, 31);
            this.btn_searchPrice.TabIndex = 3;
            this.btn_searchPrice.Text = "Price";
            this.btn_searchPrice.UseVisualStyleBackColor = true;
            this.btn_searchPrice.Click += new System.EventHandler(this.btn_searchPrice_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(59, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 30);
            this.label2.TabIndex = 4;
            this.label2.Text = "Input:";
            // 
            // tb_inv
            // 
            this.tb_inv.Location = new System.Drawing.Point(64, 92);
            this.tb_inv.Name = "tb_inv";
            this.tb_inv.Size = new System.Drawing.Size(644, 281);
            this.tb_inv.TabIndex = 5;
            this.tb_inv.Text = "";
            // 
            // btn_back
            // 
            this.btn_back.Location = new System.Drawing.Point(337, 407);
            this.btn_back.Name = "btn_back";
            this.btn_back.Size = new System.Drawing.Size(75, 31);
            this.btn_back.TabIndex = 6;
            this.btn_back.Text = "Back";
            this.btn_back.UseVisualStyleBackColor = true;
            this.btn_back.Click += new System.EventHandler(this.btn_back_Click);
            // 
            // Search
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_back);
            this.Controls.Add(this.tb_inv);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btn_searchPrice);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_searchAisle);
            this.Controls.Add(this.tb_input);
            this.Name = "Search";
            this.Text = "Search";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tb_input;
        private System.Windows.Forms.Button btn_searchAisle;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_searchPrice;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RichTextBox tb_inv;
        private System.Windows.Forms.Button btn_back;
    }
}